#!/usr/bin/env python3
import argparse, json, subprocess, sys, pathlib, time

TESTS = [
    "00_basic_soc_boot",
    "01_rsm_branch_rollback",
    "02_aegis_commit_gate",
    "03_topology_route_fabric",
    "04_tensor_aegis_rsm",
    "05_quantum_sync_audit",
    "06_full_system_ai_versioned_secure",
]

def main():
    ap = argparse.ArgumentParser(description="Nexus-V SoC regression runner")
    ap.add_argument("--program-dir", default="programs")
    ap.add_argument("--generated-dir", default="generated")
    ap.add_argument("--reports-dir", default="reports")
    ap.add_argument("--toolchain", default="nvisc-bridge", help="NVASM->NVIR/NVOBJ bridge command")
    ap.add_argument("--sim", default="rtl-sim", help="RTL simulator command placeholder")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    pathlib.Path(args.generated_dir).mkdir(exist_ok=True)
    pathlib.Path(args.reports_dir).mkdir(exist_ok=True)
    results = []

    for test in TESTS:
        src = pathlib.Path(args.program_dir) / f"{test}.nvasm"
        if not src.exists():
            results.append({"name": test, "passed": False, "reason": "missing program"})
            continue
        nvir = pathlib.Path(args.generated_dir) / f"{test}.nvir.json"
        nvobj = pathlib.Path(args.generated_dir) / f"{test}.nvobj"
        vectors = pathlib.Path(args.generated_dir) / f"{test}.rtl_vectors.json"
        if args.dry_run:
            results.append({"name": test, "passed": True, "mode": "dry-run"})
            continue
        # Placeholder command shape. Wire to the real bridge/simulator once installed.
        compile_cmd = [args.toolchain, "compile", str(src), "--nvir", str(nvir), "--nvobj", str(nvobj), "--rtl-vectors", str(vectors)]
        sim_cmd = [args.sim, "--vectors", str(vectors), "--test", test]
        try:
            subprocess.run(compile_cmd, check=True)
            subprocess.run(sim_cmd, check=True)
            results.append({"name": test, "passed": True})
        except Exception as e:
            results.append({"name": test, "passed": False, "reason": str(e)})

    summary = {"suite":"nexus_v_soc_regression_v0_1", "passed": all(r.get("passed") for r in results), "tests": results}
    out = pathlib.Path(args.reports_dir) / "regression_summary.json"
    out.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    return 0 if summary["passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
