#!/usr/bin/env python3
import argparse, json, sys

def load(path):
    with open(path, 'r') as f:
        return json.load(f)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("expected")
    ap.add_argument("observed")
    args = ap.parse_args()
    exp = load(args.expected)
    obs = load(args.observed)
    exp_events = [(e.get("type"), e.get("branch_id"), e.get("state_id"), e.get("commit_id")) for e in exp.get("events", [])]
    obs_events = [(e.get("type"), e.get("branch_id"), e.get("state_id"), e.get("commit_id")) for e in obs.get("events", [])]
    ok = exp_events == obs_events
    print(json.dumps({"passed": ok, "expected_events": len(exp_events), "observed_events": len(obs_events)}, indent=2))
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
