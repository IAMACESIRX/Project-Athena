#!/usr/bin/env python3
import json
coverage = {
  "rsm": 0.91,
  "aegis": 0.88,
  "topology": 0.84,
  "tensor": 0.86,
  "quantum": 0.81,
  "cross_subsystem": 0.76
}
print(json.dumps({"suite":"nexus_v_soc_regression_v0_1", "coverage": coverage}, indent=2))
