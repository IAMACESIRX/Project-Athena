`timescale 1ns / 1ps

import nvisc_pkg::*;

module nvisc_rhombic_dodeca_router_v0 #(
    parameter int NODE_COUNT = 16
)(
    input  logic clk,
    input  logic rst_n,

    input  logic route_req_i,
    input  logic [7:0] source_node_i,
    input  logic [7:0] target_node_i,
    input  nvisc_route_policy_e policy_i,

    input  logic [15:0] topology_epoch_i,
    input  logic [15:0] thermal_epoch_i,
    input  logic [2:0]  privilege_level_i,
    input  logic        aegis_route_approved_i,

    input  logic [NODE_COUNT-1:0] node_trusted_i,
    input  logic [NODE_COUNT-1:0] node_hot_i,
    input  logic [NODE_COUNT-1:0] node_fault_i,

    output logic route_valid_o,
    output logic route_fault_o,
    output logic route_busy_o,
    output nvisc_topology_token_t topology_token_o
);

    nvisc_topology_token_t token_q;
    logic source_in_range;
    logic target_in_range;
    logic source_ok;
    logic target_ok;
    logic safe_ok;
    logic cool_ok;
    logic policy_ok;
    logic [15:0] path_id_comb;

    assign source_in_range = (source_node_i < NODE_COUNT);
    assign target_in_range = (target_node_i < NODE_COUNT);

    assign source_ok = source_in_range && !node_fault_i[source_node_i];
    assign target_ok = target_in_range && !node_fault_i[target_node_i];

    assign safe_ok = node_trusted_i[source_node_i] && node_trusted_i[target_node_i];
    assign cool_ok = !node_hot_i[source_node_i] && !node_hot_i[target_node_i];

    always_comb begin
        policy_ok = 1'b0;
        unique case (policy_i)
            ROUTE_FAST:      policy_ok = source_ok && target_ok;
            ROUTE_SAFE:      policy_ok = source_ok && target_ok && safe_ok && aegis_route_approved_i;
            ROUTE_COOL:      policy_ok = source_ok && target_ok && cool_ok;
            ROUTE_LOW_POWER: policy_ok = source_ok && target_ok;
            ROUTE_REDUNDANT: policy_ok = source_ok && target_ok && safe_ok && cool_ok;
            default:         policy_ok = 1'b0;
        endcase
    end

    assign path_id_comb = {source_node_i[5:0], target_node_i[5:0], policy_i[2:0], 1'b0};

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            token_q <= '0;
            route_valid_o <= 1'b0;
            route_fault_o <= 1'b0;
            route_busy_o  <= 1'b0;
        end else begin
            route_valid_o <= 1'b0;
            route_fault_o <= 1'b0;
            route_busy_o  <= 1'b0;

            if (route_req_i) begin
                if (!source_in_range || !target_in_range || !policy_ok) begin
                    token_q <= '0;
                    route_fault_o <= 1'b1;
                end else begin
                    token_q.valid            <= 1'b1;
                    token_q.token_id         <= {8'h52, source_node_i, target_node_i, policy_i};
                    token_q.source_node      <= source_node_i;
                    token_q.target_node      <= target_node_i;
                    token_q.path_id          <= path_id_comb;
                    token_q.policy           <= policy_i;
                    token_q.topology_epoch   <= topology_epoch_i;
                    token_q.thermal_epoch    <= thermal_epoch_i;
                    token_q.privilege_level  <= privilege_level_i;
                    token_q.aegis_approved   <= aegis_route_approved_i;
                    route_valid_o <= 1'b1;
                end
            end
        end
    end

    assign topology_token_o = token_q;

endmodule
