`timescale 1ns / 1ps

import nvisc_pkg::*;

module nexus_v_phase0_core (
    input  logic clk,
    input  logic rst_n,

    input  logic          instr_valid_i,
    input  nvisc_alu_op_e alu_op_i,
    input  nvisc_domain_e domain_i,

    input  logic [4:0]    src_a_i,
    input  logic [4:0]    src_b_i,
    input  logic [4:0]    dst_i,
    input  logic          dst_we_i,

    input  logic          dbg_r_we_i,
    input  logic [4:0]    dbg_r_waddr_i,
    input  logic [XLEN-1:0] dbg_r_wdata_i,

    input  logic          token_state_advance_i,
    input  logic [31:0]   next_state_id_i,

    output logic [XLEN-1:0] alu_result_o,
    output logic            alu_valid_o,
    output logic            zero_o,
    output logic            negative_o,
    output nvisc_state_token_t state_token_o
);

    logic [XLEN-1:0] r_a;
    logic [XLEN-1:0] r_b;
    logic [XLEN-1:0] alu_result;
    logic [MLEN-1:0] m_dummy_a;
    logic [MLEN-1:0] m_dummy_b;
    logic [MLEN-1:0] m_result;
    logic carry;
    logic overflow;

    assign m_dummy_a = '0;
    assign m_dummy_b = '0;

    nvisc_regfile u_regfile (
        .clk(clk), .rst_n(rst_n),
        .r_we((dst_we_i && alu_valid_o) || dbg_r_we_i),
        .r_waddr(dbg_r_we_i ? dbg_r_waddr_i : dst_i),
        .r_wdata(dbg_r_we_i ? dbg_r_wdata_i : alu_result),
        .r_raddr_a(src_a_i), .r_raddr_b(src_b_i),
        .r_rdata_a(r_a), .r_rdata_b(r_b),
        .f_we(1'b0), .f_waddr('0), .f_wdata('0), .f_raddr_a('0), .f_rdata_a(),
        .d_we(1'b0), .d_waddr('0), .d_wdata('0), .d_raddr_a('0), .d_rdata_a(),
        .m_we(1'b0), .m_waddr('0), .m_wdata('0), .m_raddr_a('0), .m_rdata_a(),
        .t_we(1'b0), .t_waddr('0), .t_wdata('0), .t_raddr_a('0), .t_rdata_a(),
        .s_we(1'b0), .s_waddr('0), .s_wdata('0), .s_raddr_a('0), .s_rdata_a(),
        .p_we(1'b0), .p_waddr('0), .p_wdata('0), .p_raddr_a('0), .p_rdata_a(),
        .c_we(1'b0), .c_waddr('0), .c_wdata('0), .c_raddr_a('0), .c_rdata_a()
    );

    nvisc_alu_slice u_alu (
        .valid_i(instr_valid_i), .op_i(alu_op_i), .domain_i(domain_i),
        .a_i(r_a), .b_i(r_b), .m_a_i(m_dummy_a), .m_b_i(m_dummy_b),
        .valid_o(alu_valid_o), .result_o(alu_result), .m_result_o(m_result),
        .zero_o(zero_o), .negative_o(negative_o), .carry_o(carry), .overflow_o(overflow)
    );

    nvisc_state_token_if u_state_token (
        .clk(clk), .rst_n(rst_n),
        .update_i(1'b0), .token_i('0),
        .branch_advance_i(1'b0), .next_branch_id_i('0),
        .state_advance_i(token_state_advance_i), .next_state_id_i(next_state_id_i),
        .commit_advance_i(1'b0), .next_commit_id_i('0),
        .topology_epoch_inc_i(1'b0), .thermal_epoch_inc_i(1'b0),
        .set_committed_i(1'b0), .set_sealed_i(1'b0), .set_rollback_valid_i(1'b0),
        .token_o(state_token_o)
    );

    assign alu_result_o = alu_result;

endmodule
