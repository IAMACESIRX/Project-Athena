`timescale 1ns / 1ps

import nvisc_pkg::*;

module tb_nexus_v_phase0_core;

    logic clk;
    logic rst_n;
    logic instr_valid;
    nvisc_alu_op_e alu_op;
    nvisc_domain_e domain;
    logic [4:0] src_a;
    logic [4:0] src_b;
    logic [4:0] dst;
    logic dst_we;
    logic dbg_r_we;
    logic [4:0] dbg_r_waddr;
    logic [XLEN-1:0] dbg_r_wdata;
    logic token_state_advance;
    logic [31:0] next_state_id;
    logic [XLEN-1:0] alu_result;
    logic alu_valid;
    logic zero;
    logic negative;
    nvisc_state_token_t state_token;

    nexus_v_phase0_core dut (.*,
        .instr_valid_i(instr_valid), .alu_op_i(alu_op), .domain_i(domain),
        .src_a_i(src_a), .src_b_i(src_b), .dst_i(dst), .dst_we_i(dst_we),
        .dbg_r_we_i(dbg_r_we), .dbg_r_waddr_i(dbg_r_waddr), .dbg_r_wdata_i(dbg_r_wdata),
        .token_state_advance_i(token_state_advance), .next_state_id_i(next_state_id),
        .alu_result_o(alu_result), .alu_valid_o(alu_valid), .zero_o(zero), .negative_o(negative),
        .state_token_o(state_token)
    );

    always #5 clk = ~clk;

    task dbg_write(input logic [4:0] addr, input logic [XLEN-1:0] data);
        begin
            dbg_r_we = 1'b1;
            dbg_r_waddr = addr;
            dbg_r_wdata = data;
            @(posedge clk);
            dbg_r_we = 1'b0;
            dbg_r_waddr = '0;
            dbg_r_wdata = '0;
            @(posedge clk);
        end
    endtask

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        instr_valid = 1'b0;
        alu_op = ALU_NOP;
        domain = DOMAIN_BIN;
        src_a = '0; src_b = '0; dst = '0; dst_we = 1'b0;
        dbg_r_we = 1'b0; dbg_r_waddr = '0; dbg_r_wdata = '0;
        token_state_advance = 1'b0; next_state_id = '0;

        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        assert(state_token.valid == 1'b1) else $fatal("State token not valid after reset");
        assert(state_token.branch_id == 32'd0) else $fatal("Initial branch_id expected 0");
        assert(state_token.state_id == 32'd0) else $fatal("Initial state_id expected 0");

        token_state_advance = 1'b1;
        next_state_id = 32'd1;
        @(posedge clk);
        token_state_advance = 1'b0;
        @(posedge clk);
        assert(state_token.state_id == 32'd1) else $fatal("State token did not advance");

        dbg_write(5'd1, 64'd10);
        dbg_write(5'd2, 64'd32);

        instr_valid = 1'b1;
        alu_op = ALU_ADD;
        src_a = 5'd1;
        src_b = 5'd2;
        dst = 5'd3;
        dst_we = 1'b1;
        @(posedge clk);
        @(posedge clk);
        assert(alu_valid == 1'b1) else $fatal("ALU valid not asserted");
        assert(alu_result == 64'd42) else $fatal("ALU ADD expected 42, got %0d", alu_result);

        alu_op = ALU_SUB;
        src_a = 5'd2;
        src_b = 5'd1;
        dst = 5'd4;
        @(posedge clk);
        @(posedge clk);
        assert(alu_result == 64'd22) else $fatal("ALU SUB expected 22, got %0d", alu_result);

        $display("Nexus-V Phase 0 smoke tests passed.");
        $finish;
    end

endmodule
