`timescale 1ns / 1ps

package nvisc_common_pkg;

    parameter int NVISC_ID_W      = 32;
    parameter int NVISC_HASH_W    = 128;
    parameter int NVISC_TOKEN_W   = 32;
    parameter int NVISC_EPOCH_W   = 16;
    parameter int NVISC_SCORE_W   = 8;
    parameter int NVISC_NODE_W    = 16;
    parameter int NVISC_ADDR_W    = 32;
    parameter int NVISC_FAULT_W   = 16;

    typedef enum logic [4:0] {
        DOMAIN_BIN      = 5'd0,
        DOMAIN_TERN     = 5'd1,
        DOMAIN_QUAD     = 5'd2,
        DOMAIN_NSTATE   = 5'd3,
        DOMAIN_DEC      = 5'd4,
        DOMAIN_FLOAT    = 5'd5,
        DOMAIN_TENSOR   = 5'd6,
        DOMAIN_STATE    = 5'd7,
        DOMAIN_QSIM     = 5'd8,
        DOMAIN_QHW      = 5'd9,
        DOMAIN_HYBRID   = 5'd10,
        DOMAIN_AEGIS    = 5'd11,
        DOMAIN_TOPOLOGY = 5'd12
    } nvisc_domain_e;

    typedef enum logic [2:0] {
        ROUTE_FAST      = 3'd0,
        ROUTE_SAFE      = 3'd1,
        ROUTE_COOL      = 3'd2,
        ROUTE_LOW_POWER = 3'd3,
        ROUTE_REDUNDANT = 3'd4
    } nvisc_route_policy_e;

    typedef enum logic [2:0] {
        COMMIT_NONE       = 3'd0,
        COMMIT_ALLOW      = 3'd1,
        COMMIT_DENY       = 3'd2,
        COMMIT_REFUSE     = 3'd3,
        COMMIT_QUARANTINE = 3'd4,
        COMMIT_ROLLBACK   = 3'd5
    } nvisc_commit_result_e;

    typedef enum logic [3:0] {
        QMODE_NONE = 4'd0,
        QMODE_QSIM = 4'd1,
        QMODE_QHW  = 4'd2
    } nvisc_qmode_e;

    typedef enum logic [NVISC_FAULT_W-1:0] {
        FAULT_NONE                    = 16'h0000,
        FAULT_INVALID_OPCODE          = 16'h0001,
        FAULT_INVALID_OPERAND         = 16'h0002,
        FAULT_INVALID_DOMAIN          = 16'h0003,
        FAULT_RSM_COW_DENIED          = 16'h0100,
        FAULT_RSM_ROLLBACK_INVALID    = 16'h0101,
        FAULT_AEGIS_AUDIT_REQUIRED    = 16'h0200,
        FAULT_AEGIS_HASH_MISMATCH     = 16'h0201,
        FAULT_AEGIS_TAMPER            = 16'h0202,
        FAULT_ROUTE_UNREACHABLE       = 16'h0300,
        FAULT_ROUTE_AEGIS_DENIED      = 16'h0301,
        FAULT_TENSOR_SHAPE_MISMATCH   = 16'h0400,
        FAULT_TENSOR_NUMERIC_INVALID  = 16'h0401,
        FAULT_QUANTUM_QMODE_MISMATCH  = 16'h0500,
        FAULT_QUANTUM_USE_COLLAPSED   = 16'h0501,
        FAULT_QUANTUM_LOW_FIDELITY    = 16'h0502,
        FAULT_PRIVILEGE               = 16'h0600,
        FAULT_STALE_TOKEN             = 16'h0700
    } nvisc_fault_code_e;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_ID_W-1:0]        branch_id;
        logic [NVISC_ID_W-1:0]        state_id;
        logic [NVISC_ID_W-1:0]        commit_id;
        logic [NVISC_EPOCH_W-1:0]     topology_epoch;
        logic [NVISC_EPOCH_W-1:0]     thermal_epoch;
        nvisc_domain_e                domain;
        logic                         committed;
        logic                         sealed;
        logic                         rollback_valid;
    } nvisc_state_token_t;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_TOKEN_W-1:0]     token_id;
        logic [NVISC_ID_W-1:0]        subject_state_id;
        logic [NVISC_ID_W-1:0]        subject_branch_id;
        logic [NVISC_HASH_W-1:0]      subject_hash;
        logic [15:0]                  policy_id;
        logic [NVISC_SCORE_W-1:0]     trust_score;
        logic                         allow_commit;
        logic                         expires_on_state_change;
    } nvisc_audit_token_t;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_TOKEN_W-1:0]     route_id;
        logic [NVISC_NODE_W-1:0]      src_node;
        logic [NVISC_NODE_W-1:0]      dst_node;
        nvisc_route_policy_e          policy;
        logic [NVISC_ID_W-1:0]        branch_id;
        logic [NVISC_ID_W-1:0]        state_id;
        logic [NVISC_EPOCH_W-1:0]     topology_epoch;
        logic [NVISC_EPOCH_W-1:0]     thermal_epoch;
        logic                         aegis_approved;
        logic                         completed;
        logic                         faulted;
    } nvisc_route_token_t;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_TOKEN_W-1:0]     tensor_token_id;
        logic [NVISC_ID_W-1:0]        tensor_id;
        logic [NVISC_ID_W-1:0]        branch_id;
        logic [NVISC_ID_W-1:0]        state_id;
        logic [15:0]                  rows;
        logic [15:0]                  cols;
        logic [15:0]                  inner_dim;
        logic [2:0]                   dtype;
        logic                         numeric_ok;
        logic                         aegis_audited;
    } nvisc_tensor_token_t;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_TOKEN_W-1:0]     qtoken_id;
        logic [NVISC_ID_W-1:0]        qreg_id;
        logic [NVISC_ID_W-1:0]        branch_id;
        logic [NVISC_ID_W-1:0]        state_id;
        nvisc_qmode_e                 qmode;
        logic [7:0]                   measurement_value;
        logic [7:0]                   probability;
        logic [7:0]                   fidelity_score;
        logic                         measured;
        logic                         synced;
        logic                         audited;
        logic                         expired;
    } nvisc_quantum_token_t;

    typedef struct packed {
        logic                         valid;
        logic [NVISC_FAULT_W-1:0]     fault_code;
        nvisc_commit_result_e         commit_result;
        logic [NVISC_SCORE_W-1:0]     trust_score;
        logic [NVISC_ID_W-1:0]        active_branch_id;
        logic [NVISC_ID_W-1:0]        active_state_id;
        logic [NVISC_ID_W-1:0]        active_commit_id;
        logic                         aegis_active;
        logic                         rsm_ready;
        logic                         topology_ready;
        logic                         tensor_ready;
        logic                         quantum_ready;
    } nvisc_soc_status_t;

endpackage
