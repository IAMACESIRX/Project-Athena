`timescale 1ns / 1ps

import nvisc_common_pkg::*;

module nexus_v_soc (
    input  logic clk,
    input  logic rst_n,
    output nvisc_soc_status_t soc_status_o
);

    nvisc_soc_status_t status_q;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            status_q <= '0;
        end else begin
            status_q.valid            <= 1'b1;
            status_q.fault_code       <= FAULT_NONE;
            status_q.commit_result    <= COMMIT_NONE;
            status_q.trust_score      <= 8'd255;
            status_q.active_branch_id <= 32'd0;
            status_q.active_state_id  <= 32'd0;
            status_q.active_commit_id <= 32'd0;
            status_q.aegis_active     <= 1'b1;
            status_q.rsm_ready        <= 1'b1;
            status_q.topology_ready   <= 1'b1;
            status_q.tensor_ready     <= 1'b1;
            status_q.quantum_ready    <= 1'b1;
        end
    end

    assign soc_status_o = status_q;

endmodule
