`timescale 1ns / 1ps

import nvisc_common_pkg::*;

module tb_nexus_v_soc_smoke;

    logic clk;
    logic rst_n;

    nvisc_soc_status_t soc_status;

    // Replace this placeholder with the real nexus_v_soc once the canonical tree is merged.
    nexus_v_soc dut (
        .clk(clk),
        .rst_n(rst_n),
        .soc_status_o(soc_status)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;

        repeat (10) @(posedge clk);
        rst_n = 1'b1;

        repeat (20) @(posedge clk);

        assert(soc_status.valid) else $fatal("SoC status was not valid after reset");
        assert(soc_status.aegis_active) else $fatal("Aegis inactive after reset");
        assert(soc_status.rsm_ready) else $fatal("RSM not ready after reset");
        assert(soc_status.topology_ready) else $fatal("Topology fabric not ready after reset");
        assert(soc_status.tensor_ready) else $fatal("Tensor engine not ready after reset");
        assert(soc_status.quantum_ready) else $fatal("Quantum domain not ready after reset");
        assert(soc_status.active_branch_id == 32'd0) else $fatal("Unexpected initial branch id");
        assert(soc_status.active_state_id == 32'd0) else $fatal("Unexpected initial state id");

        $display("Nexus-V SoC smoke reset passed.");
        $finish;
    end

endmodule
